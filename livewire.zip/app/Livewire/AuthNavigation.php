<?php

namespace App\Livewire;

use Livewire\Component;

class AuthNavigation extends Component
{
    public function render()
    {
        return view('livewire.auth-navigation');
    }
}
